/* sw.js — cache do app shell para funcionamento offline */
const CACHE_NAME = 'grana-cache-v8';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './js/app.js',
  './js/db.js',
  './js/utils/helpers.js',
  './js/utils/modal.js',
  './js/utils/notifications.js',
  './js/utils/export.js',
  './js/utils/importer.js',
  './js/modules/dashboard.js',
  './js/modules/transactions.js',
  './js/modules/cards.js',
  './js/modules/calendar.js',
  './js/modules/goals.js',
  './js/modules/reports.js',
  './js/modules/settings.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      Promise.all(ASSETS.map((url) => cache.add(url).catch(() => {})))
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req)
        .then((res) => {
          // Cacheia dinamicamente libs externas (ex: SheetJS, jsPDF) na primeira vez que forem usadas
          if (res.ok && (req.url.startsWith('http'))) {
            const resClone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
          }
          return res;
        })
        .catch(() => cached);
    })
  );
});
