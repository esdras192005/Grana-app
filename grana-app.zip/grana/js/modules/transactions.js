/* transactions.js — lançamentos: cadastro, filtro, busca, recorrência */
App.register('transactions', (function () {
  let viewMonth = App.currentMonth();
  let searchTerm = '';
  let typeFilter = 'todos';

  async function render(container) {
    const { el } = Fmt;
    const categories = await DB.all('categories');
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));
    let items = await DB.getTransactionsByMonth(viewMonth);

    if (typeFilter !== 'todos') items = items.filter(t => t.type === typeFilter);
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      items = items.filter(t =>
        (t.description || '').toLowerCase().includes(q) ||
        (catMap[t.categoryId] && catMap[t.categoryId].name.toLowerCase().includes(q))
      );
    }
    items.sort((a, b) => (a.date < b.date ? 1 : -1));

    const wrap = el('div', { class: 'screen transactions' });

    wrap.appendChild(el('div', { class: 'top-row' }, [
      el('h2', {}, 'Transações'),
      el('button', { class: 'btn-primary small', onclick: () => openTransactionModal(null, catMap) }, '+ Novo'),
    ]));

    wrap.appendChild(el('div', { class: 'month-switch' }, [
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, -1); render(container); } }, '‹'),
      el('div', { class: 'month-switch-label' }, Fmt.monthLabel(viewMonth)),
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, 1); render(container); } }, '›'),
    ]));

    const searchRow = el('div', { class: 'search-row' });
    const searchInput = el('input', { class: 'input', placeholder: 'Buscar transação ou categoria...', value: searchTerm });
    searchInput.addEventListener('input', (e) => { searchTerm = e.target.value; render(container); });
    searchRow.appendChild(searchInput);
    wrap.appendChild(searchRow);

    const filterRow = el('div', { class: 'chip-row' });
    for (const [key, label] of [['todos', 'Todos'], ['receita', 'Receitas'], ['despesa', 'Despesas']]) {
      const chip = el('button', { class: `chip ${typeFilter === key ? 'active' : ''}` }, label);
      chip.addEventListener('click', () => { typeFilter = key; render(container); });
      filterRow.appendChild(chip);
    }
    wrap.appendChild(filterRow);

    const list = el('div', { class: 'tx-list' });
    if (items.length === 0) {
      list.appendChild(el('p', { class: 'muted center' }, 'Nenhuma transação encontrada.'));
    } else {
      for (const t of items) list.appendChild(txRow(t, catMap, container));
    }
    wrap.appendChild(list);

    wrap.appendChild(el('div', { class: 'row-buttons' }, [
      el('button', { class: 'btn-secondary', onclick: () => openRecurringModal(catMap) }, '🔁 Contas recorrentes'),
      el('button', { class: 'btn-secondary', onclick: () => openCategoryModal() }, '🏷️ Categorias'),
    ]));

    container.appendChild(wrap);
  }

  function txRow(t, catMap, container) {
    const { el } = Fmt;
    const cat = catMap[t.categoryId] || { name: 'Outros', icon: '📦', color: '#8A95A5' };
    const row = el('div', { class: 'tx-row' }, [
      el('div', { class: 'tx-icon', style: `background:${cat.color}22;color:${cat.color}` }, cat.icon),
      el('div', { class: 'tx-info' }, [
        el('div', { class: 'tx-desc' }, t.description || cat.name),
        el('div', { class: 'tx-meta muted' }, `${cat.name} · ${Fmt.dateBR(t.date)}`),
      ]),
      el('div', { class: `tx-amount ${t.type === 'receita' ? 'pos-text' : 'neg-text'}` },
        `${t.type === 'receita' ? '+' : '-'} ${Fmt.moneyCompact(t.amount)}`),
    ]);
    row.addEventListener('click', () => openTransactionModal(t, catMap, container));
    return row;
  }

  function openTransactionModal(existing, catMap, container) {
    const cats = Object.values(catMap);
    const isEdit = !!existing;
    const t = existing || { type: 'despesa', date: Fmt.todayISO(), amount: '', categoryId: cats[0] ? cats[0].id : '', description: '' };

    const catOptions = (type) => cats.filter(c => c.type === type).map(c =>
      `<option value="${c.id}" ${t.categoryId === c.id ? 'selected' : ''}>${c.icon} ${c.name}</option>`
    ).join('');

    Modal.open({
      title: isEdit ? 'Editar transação' : 'Nova transação',
      body: `
        <div class="segmented" id="type-segment">
          <button type="button" class="seg-btn ${t.type === 'despesa' ? 'active' : ''}" data-type="despesa">Despesa</button>
          <button type="button" class="seg-btn ${t.type === 'receita' ? 'active' : ''}" data-type="receita">Receita</button>
        </div>
        <label class="field-label">Valor</label>
        <input type="number" step="0.01" id="tx-amount" class="input" value="${t.amount}" placeholder="0,00" />
        <label class="field-label">Categoria</label>
        <select id="tx-category" class="input">${catOptions(t.type)}</select>
        <label class="field-label">Data</label>
        <input type="date" id="tx-date" class="input" value="${t.date}" />
        <label class="field-label">Descrição (opcional)</label>
        <input type="text" id="tx-desc" class="input" value="${t.description || ''}" placeholder="Ex: Mercado do mês" />
      `,
      confirmLabel: isEdit ? 'Salvar' : 'Adicionar',
      onConfirm: async () => {
        const amount = parseFloat(document.getElementById('tx-amount').value);
        if (!amount || amount <= 0) return Fmt.toast('Informe um valor válido');
        const typeBtn = document.querySelector('#type-segment .seg-btn.active');
        const record = {
          type: typeBtn.dataset.type,
          amount,
          categoryId: document.getElementById('tx-category').value,
          date: document.getElementById('tx-date').value,
          description: document.getElementById('tx-desc').value.trim(),
        };
        if (isEdit) record.id = existing.id;
        await DB.put('transactions', record);
        Modal.close();
        Fmt.toast(isEdit ? 'Transação atualizada' : 'Transação adicionada');
        App.navigate('transactions');
      },
    });

    document.querySelectorAll('#type-segment .seg-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#type-segment .seg-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById('tx-category').innerHTML = catOptions(btn.dataset.type);
      });
    });

    if (isEdit) {
      const modalActions = document.querySelector('.modal-actions');
      const delBtn = Fmt.el('button', { class: 'btn-danger' }, 'Excluir');
      delBtn.addEventListener('click', async () => {
        await DB.remove('transactions', existing.id);
        Modal.close();
        Fmt.toast('Transação excluída');
        App.navigate('transactions');
      });
      modalActions.prepend(delBtn);
    }
  }

  function openCategoryModal() {
    renderCategoryList();
  }

  async function renderCategoryList() {
    const cats = await DB.all('categories');
    const rows = cats.map(c => `
      <div class="cat-row" data-id="${c.id}">
        <span class="legend-dot" style="background:${c.color}"></span>
        <span>${c.icon} ${c.name}</span>
        <span class="muted">${c.type === 'receita' ? 'Receita' : 'Despesa'}</span>
        <button class="link-btn del-cat" data-id="${c.id}">Excluir</button>
      </div>
    `).join('');

    Modal.open({
      title: 'Categorias',
      body: `
        <div class="cat-list">${rows}</div>
        <hr class="divider" />
        <label class="field-label">Nova categoria</label>
        <input type="text" id="new-cat-name" class="input" placeholder="Nome" />
        <div class="row-2">
          <input type="text" id="new-cat-icon" class="input" placeholder="Emoji (ex: 🛒)" maxlength="2" />
          <input type="color" id="new-cat-color" class="input color-input" value="#00D9A3" />
        </div>
        <div class="segmented" id="new-cat-type">
          <button type="button" class="seg-btn active" data-type="despesa">Despesa</button>
          <button type="button" class="seg-btn" data-type="receita">Receita</button>
        </div>
      `,
      confirmLabel: 'Adicionar categoria',
      onConfirm: async () => {
        const name = document.getElementById('new-cat-name').value.trim();
        if (!name) return Fmt.toast('Digite um nome para a categoria');
        const icon = document.getElementById('new-cat-icon').value.trim() || '📦';
        const color = document.getElementById('new-cat-color').value;
        const type = document.querySelector('#new-cat-type .seg-btn.active').dataset.type;
        await DB.put('categories', { name, icon, color, type });
        Fmt.toast('Categoria adicionada');
        renderCategoryList();
      },
    });

    document.querySelectorAll('#new-cat-type .seg-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#new-cat-type .seg-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
    document.querySelectorAll('.del-cat').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await DB.remove('categories', isNaN(btn.dataset.id) ? btn.dataset.id : Number(btn.dataset.id));
        Fmt.toast('Categoria excluída');
        renderCategoryList();
      });
    });
  }

  function openRecurringModal(catMap) {
    renderRecurringList(catMap);
  }

  async function renderRecurringList(catMap) {
    const recs = await DB.all('recurring');
    const cats = Object.values(catMap);
    const rows = recs.map(r => `
      <div class="cat-row">
        <span>${r.description}</span>
        <span class="muted">${r.frequency}</span>
        <span class="neg-text">${Fmt.money(r.amount)}</span>
        <button class="link-btn del-rec" data-id="${r.id}">Excluir</button>
      </div>
    `).join('') || '<p class="muted">Nenhuma conta recorrente cadastrada.</p>';

    const catOptions = cats.filter(c => c.type === 'despesa').map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join('');

    Modal.open({
      title: 'Contas recorrentes',
      body: `
        <div class="cat-list">${rows}</div>
        <hr class="divider" />
        <label class="field-label">Descrição</label>
        <input type="text" id="rec-desc" class="input" placeholder="Ex: Aluguel" />
        <label class="field-label">Valor</label>
        <input type="number" step="0.01" id="rec-amount" class="input" placeholder="0,00" />
        <label class="field-label">Categoria</label>
        <select id="rec-category" class="input">${catOptions}</select>
        <label class="field-label">Frequência</label>
        <select id="rec-freq" class="input">
          <option value="mensal">Mensal</option>
          <option value="semanal">Semanal</option>
          <option value="quinzenal">Quinzenal</option>
          <option value="anual">Anual</option>
        </select>
        <label class="field-label">Próximo vencimento</label>
        <input type="date" id="rec-date" class="input" value="${Fmt.todayISO()}" />
      `,
      confirmLabel: 'Adicionar recorrência',
      onConfirm: async () => {
        const description = document.getElementById('rec-desc').value.trim();
        const amount = parseFloat(document.getElementById('rec-amount').value);
        if (!description || !amount) return Fmt.toast('Preencha descrição e valor');
        await DB.put('recurring', {
          description, amount,
          categoryId: document.getElementById('rec-category').value,
          frequency: document.getElementById('rec-freq').value,
          nextDate: document.getElementById('rec-date').value,
          type: 'despesa',
          active: true,
        });
        Fmt.toast('Recorrência adicionada');
        renderRecurringList(catMap);
      },
    });

    document.querySelectorAll('.del-rec').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await DB.remove('recurring', Number(btn.dataset.id));
        Fmt.toast('Recorrência excluída');
        renderRecurringList(catMap);
      });
    });
  }

  return { render };
})());
