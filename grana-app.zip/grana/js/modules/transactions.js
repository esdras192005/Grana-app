/* transactions.js — lançamentos: cadastro, filtro, busca, recorrência */
App.register('transactions', (function () {
  let viewMonth = App.currentMonth();
  let searchTerm = '';
  let typeFilter = 'todos';
  let categoryFilter = 'todos';

  async function render(container) {
    const { el } = Fmt;
    const categories = await DB.all('categories');
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));
    let items = await DB.getTransactionsByMonth(viewMonth);

    if (typeFilter !== 'todos') items = items.filter(t => t.type === typeFilter);
    if (categoryFilter !== 'todos') items = items.filter(t => String(t.categoryId) === String(categoryFilter));
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      items = items.filter(t =>
        (t.description || '').toLowerCase().includes(q) ||
        (catMap[t.categoryId] && catMap[t.categoryId].name.toLowerCase().includes(q))
      );
    }
    items.sort((a, b) => (a.date < b.date ? 1 : -1));

    const wrap = el('div', { class: 'screen transactions' });

    wrap.appendChild(el('div', { class: 'top-row' }, [
      el('h2', {}, 'Transações'),
      el('button', { class: 'btn-primary small', onclick: () => openTransactionModal(null, catMap) }, '+ Novo'),
    ]));

    wrap.appendChild(el('div', { class: 'month-switch' }, [
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, -1); render(container); } }, '‹'),
      el('div', { class: 'month-switch-label' }, Fmt.monthLabel(viewMonth)),
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, 1); render(container); } }, '›'),
    ]));

    const searchRow = el('div', { class: 'search-row' });
    const searchInput = el('input', { class: 'input', placeholder: 'Buscar transação ou categoria...', value: searchTerm });
    searchInput.addEventListener('input', (e) => { searchTerm = e.target.value; render(container); });
    searchRow.appendChild(searchInput);
    wrap.appendChild(searchRow);

    const filterRow = el('div', { class: 'chip-row' });
    for (const [key, label] of [['todos', 'Todos'], ['receita', 'Receitas'], ['despesa', 'Despesas']]) {
      const chip = el('button', { class: `chip ${typeFilter === key ? 'active' : ''}` }, label);
      chip.addEventListener('click', () => { typeFilter = key; render(container); });
      filterRow.appendChild(chip);
    }
    wrap.appendChild(filterRow);

    const catSelect = el('select', { class: 'input cat-filter-select' });
    catSelect.appendChild(el('option', { value: 'todos' }, 'Todas as categorias'));
    for (const c of categories) {
      if (c.name === 'Ajuste de saldo') continue;
      const opt = el('option', { value: String(c.id) }, `${c.icon} ${c.name}`);
      if (String(categoryFilter) === String(c.id)) opt.selected = true;
      catSelect.appendChild(opt);
    }
    catSelect.addEventListener('change', (e) => { categoryFilter = e.target.value; render(container); });
    wrap.appendChild(catSelect);

    const list = el('div', { class: 'tx-list' });
    if (items.length === 0) {
      list.appendChild(el('p', { class: 'muted center' }, 'Nenhuma transação encontrada.'));
    } else {
      for (const t of items) list.appendChild(txRow(t, catMap, container));
    }
    wrap.appendChild(list);

    wrap.appendChild(el('div', { class: 'row-buttons' }, [
      el('button', { class: 'btn-secondary', onclick: () => App.navigate('cards') }, '💳 Cartões'),
      el('button', { class: 'btn-secondary', onclick: () => openRecurringModal(catMap) }, '🔁 Recorrentes e assinaturas'),
      el('button', { class: 'btn-secondary', onclick: () => openCategoryModal() }, '🏷️ Categorias'),
    ]));

    container.appendChild(wrap);
  }

  function txRow(t, catMap, container) {
    const { el } = Fmt;
    const cat = catMap[t.categoryId] || { name: 'Outros', icon: '📦', color: '#8A95A5' };
    const rightCol = el('div', { class: 'tx-right' }, [
      el('div', { class: `tx-amount ${t.type === 'receita' ? 'pos-text' : 'neg-text'}` },
        `${t.type === 'receita' ? '+' : '-'} ${Fmt.moneyCompact(t.amount)}`),
    ]);
    const row = el('div', { class: 'tx-row' }, [
      el('div', { class: 'tx-icon', style: `background:${cat.color}22;color:${cat.color}` }, cat.icon),
      el('div', { class: 'tx-info' }, [
        el('div', { class: 'tx-desc' }, t.description || cat.name),
        el('div', { class: 'tx-meta muted' }, `${cat.name} · ${Fmt.dateBR(t.date)}`),
      ]),
      rightCol,
    ]);
    if (t.recurringId) {
      const pill = el('button', { class: `pay-pill ${t.paid ? 'paid' : 'pending'}` }, t.paid ? '✅ Pago' : '⏳ Pendente');
      pill.addEventListener('click', async (e) => {
        e.stopPropagation();
        t.paid = !t.paid;
        await DB.put('transactions', t);
        Fmt.toast(t.paid ? 'Marcado como pago' : 'Marcado como pendente');
        App.navigate('transactions');
      });
      rightCol.appendChild(pill);
    }
    row.addEventListener('click', () => openTransactionModal(t, catMap, container));
    return row;
  }

  async function openTransactionModal(existing, catMap, container, forceAdjust) {
    const cats = Object.values(catMap);
    const isEdit = !!existing;
    const currentBalance = await DB.computeBalance();
    const t = existing || { type: 'despesa', date: Fmt.todayISO(), amount: '', categoryId: cats[0] ? cats[0].id : '', description: '' };

    const catOptions = (type) => cats.filter(c => c.type === type && c.name !== 'Ajuste de saldo').map(c =>
      `<option value="${c.id}" ${t.categoryId === c.id ? 'selected' : ''}>${c.icon} ${c.name}</option>`
    ).join('');

    const showModeToggle = !isEdit;

    Modal.open({
      title: isEdit ? 'Editar transação' : (forceAdjust ? 'Ajustar saldo atual' : 'Nova transação'),
      body: `
        ${showModeToggle ? `
        <div class="segmented" id="mode-segment">
          <button type="button" class="seg-btn ${!forceAdjust ? 'active' : ''}" data-mode="normal">Transação</button>
          <button type="button" class="seg-btn ${forceAdjust ? 'active' : ''}" data-mode="ajuste">Ajustar saldo</button>
        </div>` : ''}

        <div id="normal-fields" style="${forceAdjust ? 'display:none;' : ''}">
          <div class="segmented" id="type-segment">
            <button type="button" class="seg-btn ${t.type === 'despesa' ? 'active' : ''}" data-type="despesa">Despesa</button>
            <button type="button" class="seg-btn ${t.type === 'receita' ? 'active' : ''}" data-type="receita">Receita</button>
          </div>
          <label class="field-label">Valor</label>
          <input type="number" step="0.01" id="tx-amount" class="input" value="${t.amount}" placeholder="0,00" />
          <label class="field-label">Categoria</label>
          <select id="tx-category" class="input">${catOptions(t.type)}</select>
          <label class="field-label">Data</label>
          <input type="date" id="tx-date" class="input" value="${t.date}" />
          <label class="field-label">Descrição (opcional)</label>
          <input type="text" id="tx-desc" class="input" value="${t.description || ''}" placeholder="Ex: Mercado do mês" />
        </div>

        <div id="adjust-fields" style="${forceAdjust ? '' : 'display:none;'}">
          <p class="muted">Seu saldo atual é <strong>${Fmt.money(currentBalance)}</strong>. Informe o valor real que você tem agora e o Grana ajusta automaticamente a diferença como uma transação.</p>
          <label class="field-label">Novo saldo atual</label>
          <input type="number" step="0.01" id="adjust-balance" class="input" value="${currentBalance.toFixed(2)}" placeholder="0,00" />
          <label class="field-label">Data do ajuste</label>
          <input type="date" id="adjust-date" class="input" value="${Fmt.todayISO()}" />
        </div>
      `,
      confirmLabel: isEdit ? 'Salvar' : 'Adicionar',
      onConfirm: async () => {
        const mode = showModeToggle
          ? document.querySelector('#mode-segment .seg-btn.active').dataset.mode
          : 'normal';

        if (mode === 'ajuste') {
          const newBalance = parseFloat(document.getElementById('adjust-balance').value);
          if (isNaN(newBalance)) return Fmt.toast('Informe um valor válido');
          const diff = Math.round((newBalance - currentBalance) * 100) / 100;
          if (diff === 0) { Modal.close(); return Fmt.toast('Seu saldo já está correto'); }
          const type = diff > 0 ? 'receita' : 'despesa';
          const adjustCat = cats.find(c => c.name === 'Ajuste de saldo' && c.type === type);
          await DB.put('transactions', {
            type,
            amount: Math.abs(diff),
            categoryId: adjustCat ? adjustCat.id : cats[0].id,
            date: document.getElementById('adjust-date').value,
            description: 'Ajuste de saldo',
          });
          Modal.close();
          Fmt.toast('Saldo ajustado');
          App.navigate('dashboard');
          return;
        }

        const amount = parseFloat(document.getElementById('tx-amount').value);
        if (!amount || amount <= 0) return Fmt.toast('Informe um valor válido');
        const typeBtn = document.querySelector('#type-segment .seg-btn.active');
        const record = {
          type: typeBtn.dataset.type,
          amount,
          categoryId: document.getElementById('tx-category').value,
          date: document.getElementById('tx-date').value,
          description: document.getElementById('tx-desc').value.trim(),
        };
        if (isEdit) record.id = existing.id;
        await DB.put('transactions', record);
        Modal.close();
        Fmt.toast(isEdit ? 'Transação atualizada' : 'Transação adicionada');
        App.navigate(container ? 'transactions' : 'dashboard');
      },
    });

    if (showModeToggle) {
      document.querySelectorAll('#mode-segment .seg-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.querySelectorAll('#mode-segment .seg-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          const isAdjust = btn.dataset.mode === 'ajuste';
          document.getElementById('normal-fields').style.display = isAdjust ? 'none' : '';
          document.getElementById('adjust-fields').style.display = isAdjust ? '' : 'none';
        });
      });
    }

    document.querySelectorAll('#type-segment .seg-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#type-segment .seg-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById('tx-category').innerHTML = catOptions(btn.dataset.type);
      });
    });

    if (isEdit) {
      const modalActions = document.querySelector('.modal-actions');
      const delBtn = Fmt.el('button', { class: 'btn-danger' }, 'Excluir');
      delBtn.addEventListener('click', async () => {
        await DB.remove('transactions', existing.id);
        Modal.close();
        Fmt.toast('Transação excluída');
        App.navigate('transactions');
      });
      modalActions.prepend(delBtn);
    }
  }

  async function openAdjustBalance() {
    const categories = await DB.all('categories');
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));
    openTransactionModal(null, catMap, null, true);
  }

  function openCategoryModal() {
    renderCategoryList();
  }

  async function renderCategoryList() {
    const cats = (await DB.all('categories')).filter(c => c.name !== 'Ajuste de saldo');
    const rows = cats.map(c => `
      <div class="cat-row" data-id="${c.id}">
        <span class="legend-dot" style="background:${c.color}"></span>
        <span>${c.icon} ${c.name}</span>
        <span class="muted">${c.type === 'receita' ? 'Receita' : 'Despesa'}</span>
        <button class="link-btn del-cat" data-id="${c.id}">Excluir</button>
      </div>
    `).join('');

    Modal.open({
      title: 'Categorias',
      body: `
        <div class="cat-list">${rows}</div>
        <hr class="divider" />
        <label class="field-label">Nova categoria</label>
        <input type="text" id="new-cat-name" class="input" placeholder="Nome" />
        <div class="row-2">
          <input type="text" id="new-cat-icon" class="input" placeholder="Emoji (ex: 🛒)" maxlength="2" />
          <input type="color" id="new-cat-color" class="input color-input" value="#00D9A3" />
        </div>
        <div class="segmented" id="new-cat-type">
          <button type="button" class="seg-btn active" data-type="despesa">Despesa</button>
          <button type="button" class="seg-btn" data-type="receita">Receita</button>
        </div>
      `,
      confirmLabel: 'Adicionar categoria',
      onConfirm: async () => {
        const name = document.getElementById('new-cat-name').value.trim();
        if (!name) return Fmt.toast('Digite um nome para a categoria');
        const icon = document.getElementById('new-cat-icon').value.trim() || '📦';
        const color = document.getElementById('new-cat-color').value;
        const type = document.querySelector('#new-cat-type .seg-btn.active').dataset.type;
        await DB.put('categories', { name, icon, color, type });
        Fmt.toast('Categoria adicionada');
        renderCategoryList();
      },
    });

    document.querySelectorAll('#new-cat-type .seg-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#new-cat-type .seg-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
    document.querySelectorAll('.del-cat').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await DB.remove('categories', isNaN(btn.dataset.id) ? btn.dataset.id : Number(btn.dataset.id));
        Fmt.toast('Categoria excluída');
        renderCategoryList();
      });
    });
  }

  function openRecurringModal(catMap) {
    renderRecurringList(catMap);
  }

  async function renderRecurringList(catMap) {
    const recs = await DB.all('recurring');
    const cats = Object.values(catMap);
    recs.sort((a, b) => a.nextDate < b.nextDate ? -1 : 1);

    const subs = recs.filter(r => r.isSubscription);
    const subsTotal = subs.reduce((sum, r) => sum + DB.monthlyEquivalent(r.amount, r.frequency), 0);

    const today = Fmt.todayISO();
    const rows = recs.map(r => {
      const due = r.nextDate <= today;
      return `
      <div class="cat-row rec-row" data-id="${r.id}">
        <span>${r.isSubscription ? '📺' : '🔁'} ${r.description}${due ? ' <span class="neg-text">· vence</span>' : ''}</span>
        <span class="muted">${Fmt.dateBR(r.nextDate)}</span>
        <span class="neg-text">${Fmt.money(r.amount)}</span>
      </div>
      <div class="rec-actions">
        <button class="link-btn pay-rec" data-id="${r.id}">✅ Marcar como pago</button>
        <button class="link-btn del-rec" data-id="${r.id}">Excluir</button>
      </div>`;
    }).join('') || '<p class="muted">Nenhuma conta recorrente cadastrada.</p>';

    const catOptions = cats.filter(c => c.type === 'despesa' && c.name !== 'Ajuste de saldo').map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join('');

    Modal.open({
      title: 'Contas recorrentes e assinaturas',
      body: `
        ${subs.length ? `
        <div class="subs-summary">
          <span>📺 Total em assinaturas/mês</span>
          <span class="neg-text">${Fmt.money(subsTotal)}</span>
        </div>` : ''}
        <div class="cat-list">${rows}</div>
        <hr class="divider" />
        <label class="field-label">Descrição</label>
        <input type="text" id="rec-desc" class="input" placeholder="Ex: Netflix, Aluguel..." />
        <div class="chip-row wrap" id="quick-subs">
          ${['Netflix', 'Spotify', 'Amazon Prime', 'Disney+', 'HBO Max', 'YouTube Premium', 'iCloud', 'Google One'].map(name =>
            `<button type="button" class="chip quick-sub-chip" data-name="${name}">${name}</button>`
          ).join('')}
        </div>
        <label class="field-label">Valor</label>
        <input type="number" step="0.01" id="rec-amount" class="input" placeholder="0,00" />
        <label class="field-label">Categoria</label>
        <select id="rec-category" class="input">${catOptions}</select>
        <label class="field-label">Frequência</label>
        <select id="rec-freq" class="input">
          <option value="mensal">Mensal</option>
          <option value="semanal">Semanal</option>
          <option value="quinzenal">Quinzenal</option>
          <option value="anual">Anual</option>
        </select>
        <label class="field-label">Próximo vencimento</label>
        <input type="date" id="rec-date" class="input" value="${Fmt.todayISO()}" />
        <label class="check-row">
          <input type="checkbox" id="rec-is-sub" />
          <span>É uma assinatura (Netflix, Spotify, etc)</span>
        </label>
      `,
      confirmLabel: 'Adicionar',
      onConfirm: async () => {
        const description = document.getElementById('rec-desc').value.trim();
        const amount = parseFloat(document.getElementById('rec-amount').value);
        if (!description || !amount) return Fmt.toast('Preencha descrição e valor');
        await DB.put('recurring', {
          description, amount,
          categoryId: document.getElementById('rec-category').value,
          frequency: document.getElementById('rec-freq').value,
          nextDate: document.getElementById('rec-date').value,
          type: 'despesa',
          isSubscription: document.getElementById('rec-is-sub').checked,
          active: true,
        });
        Fmt.toast('Adicionado');
        renderRecurringList(catMap);
      },
    });

    document.querySelectorAll('.quick-sub-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        document.getElementById('rec-desc').value = chip.dataset.name;
        document.getElementById('rec-is-sub').checked = true;
        const assinaturasCat = cats.find(c => c.name === 'Assinaturas' && c.type === 'despesa');
        if (assinaturasCat) document.getElementById('rec-category').value = assinaturasCat.id;
        document.querySelectorAll('.quick-sub-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        document.getElementById('rec-amount').focus();
      });
    });

    document.querySelectorAll('.del-rec').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await DB.remove('recurring', Number(btn.dataset.id));
        Fmt.toast('Excluído');
        renderRecurringList(catMap);
      });
    });
    document.querySelectorAll('.pay-rec').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await DB.markRecurringPaid(Number(btn.dataset.id));
        Fmt.toast('Marcado como pago');
        renderRecurringList(catMap);
        if (App.modules.dashboard) App.navigate('dashboard');
      });
    });
  }

  return { render, openAdjustBalance };
})());
