/* settings.js — configurações: backup, restauração, notificações */
App.register('settings', (function () {
  async function render(container) {
    const { el } = Fmt;
    const wrap = el('div', { class: 'screen settings' });
    wrap.appendChild(el('h2', {}, 'Configurações'));

    // Importar extrato
    const importCard = el('div', { class: 'card' });
    importCard.appendChild(el('div', { class: 'card-title' }, 'Importar extrato bancário'));
    importCard.appendChild(el('p', { class: 'muted' }, 'Envie um arquivo .csv ou .ofx exportado do seu banco. Você revisa e escolhe as categorias antes de confirmar.'));
    const importInput = el('input', { type: 'file', accept: '.csv,.ofx,.qfx,.txt', id: 'import-input', style: 'display:none' });
    importInput.addEventListener('change', handleImportFile);
    importCard.appendChild(el('button', { class: 'btn-secondary', onclick: () => document.getElementById('import-input').click() }, '📥 Selecionar arquivo'));
    importCard.appendChild(importInput);
    wrap.appendChild(importCard);

    // Backup manual
    const backupCard = el('div', { class: 'card' });
    backupCard.appendChild(el('div', { class: 'card-title' }, 'Backup'));
    backupCard.appendChild(el('p', { class: 'muted' }, 'O app salva um backup automático localmente todos os dias. Você também pode baixar ou restaurar um backup manualmente.'));
    backupCard.appendChild(el('div', { class: 'row-buttons' }, [
      el('button', { class: 'btn-secondary', onclick: downloadBackup }, '⬇️ Baixar backup (.json)'),
      el('button', { class: 'btn-secondary', onclick: triggerRestore }, '⬆️ Restaurar backup'),
    ]));
    const fileInput = el('input', { type: 'file', accept: 'application/json', id: 'restore-input', style: 'display:none' });
    fileInput.addEventListener('change', handleRestoreFile);
    backupCard.appendChild(fileInput);
    wrap.appendChild(backupCard);

    // Notificações
    const notifCard = el('div', { class: 'card' });
    notifCard.appendChild(el('div', { class: 'card-title' }, 'Notificações de vencimento'));
    const status = ('Notification' in window) ? Notification.permission : 'unsupported';
    notifCard.appendChild(el('p', { class: 'muted' },
      status === 'granted' ? 'Notificações ativadas ✅' :
      status === 'unsupported' ? 'Seu navegador não suporta notificações.' :
      'Ative para ser avisado sobre contas próximas do vencimento.'));
    if (status !== 'granted' && status !== 'unsupported') {
      notifCard.appendChild(el('button', {
        class: 'btn-primary small',
        onclick: async () => { await Notifications.requestPermission(); App.navigate('settings'); },
      }, 'Ativar notificações'));
    }
    wrap.appendChild(notifCard);

    // Sobre
    const aboutCard = el('div', { class: 'card' });
    aboutCard.appendChild(el('div', { class: 'card-title' }, 'Sobre o Grana'));
    aboutCard.appendChild(el('p', { class: 'muted' }, 'Grana é um app de controle financeiro pessoal que funciona 100% offline, com todos os dados guardados apenas no seu dispositivo.'));
    wrap.appendChild(aboutCard);

    // Zona de risco
    const dangerCard = el('div', { class: 'card' });
    dangerCard.appendChild(el('div', { class: 'card-title' }, 'Zona de risco'));
    dangerCard.appendChild(el('button', { class: 'btn-danger', onclick: confirmWipe }, 'Apagar todos os dados'));
    wrap.appendChild(dangerCard);

    container.appendChild(wrap);
  }

  function handleImportFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const txs = Importer.parseFile(file.name, reader.result);
      if (!txs.length) {
        Fmt.toast('Não conseguimos ler transações desse arquivo. Tente exportar em outro formato.');
        return;
      }
      await openImportReview(txs);
    };
    reader.readAsText(file, 'utf-8');
    e.target.value = '';
  }

  async function openImportReview(txs) {
    const categories = await DB.all('categories');
    const catOptions = (type, selectedId) => categories.filter(c => c.type === type && c.name !== 'Ajuste de saldo').map(c =>
      `<option value="${c.id}" ${c.id === selectedId ? 'selected' : ''}>${c.icon} ${c.name}</option>`
    ).join('');

    const rows = txs.map((t, idx) => {
      const suggested = Importer.guessCategoryId(t.description, categories, t.type);
      return `
        <div class="import-row">
          <label class="check-row">
            <input type="checkbox" id="imp-check-${idx}" checked />
            <span class="import-desc">
              <strong>${t.description}</strong><br/>
              <span class="muted small">${Fmt.dateBR(t.date)} · <span class="${t.type === 'receita' ? 'pos-text' : 'neg-text'}">${t.type === 'receita' ? '+' : '-'} ${Fmt.moneyCompact(t.amount)}</span></span>
            </span>
          </label>
          <select id="imp-cat-${idx}" class="input import-cat-select">${catOptions(t.type, suggested)}</select>
        </div>
      `;
    }).join('');

    Modal.open({
      title: `${txs.length} transações encontradas`,
      body: `<div class="cat-list import-list">${rows}</div>`,
      confirmLabel: 'Importar selecionadas',
      onConfirm: async () => {
        let count = 0;
        for (let idx = 0; idx < txs.length; idx++) {
          const check = document.getElementById(`imp-check-${idx}`);
          if (!check || !check.checked) continue;
          const t = txs[idx];
          const categoryId = document.getElementById(`imp-cat-${idx}`).value;
          await DB.put('transactions', {
            date: t.date,
            type: t.type,
            amount: t.amount,
            categoryId,
            description: t.description,
          });
          count++;
        }
        Modal.close();
        Fmt.toast(`${count} transações importadas`);
        App.navigate('dashboard');
      },
    });
  }

  async function downloadBackup() {
    const data = await DB.exportAllData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `grana-backup-${Fmt.todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    Fmt.toast('Backup baixado');
  }

  function triggerRestore() {
    document.getElementById('restore-input').click();
  }

  function handleRestoreFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const data = JSON.parse(reader.result);
        Modal.open({
          title: 'Restaurar backup',
          body: '<p>Isso vai substituir todos os dados atuais pelos dados do arquivo selecionado. Deseja continuar?</p>',
          confirmLabel: 'Restaurar',
          onConfirm: async () => {
            await DB.importAllData(data);
            Modal.close();
            Fmt.toast('Backup restaurado');
            App.navigate('dashboard');
          },
        });
      } catch (err) {
        Fmt.toast('Arquivo inválido');
      }
    };
    reader.readAsText(file);
  }

  function confirmWipe() {
    Modal.open({
      title: 'Apagar todos os dados',
      body: '<p>Essa ação não pode ser desfeita. Todas as transações, categorias, metas e recorrências serão apagadas permanentemente.</p>',
      confirmLabel: 'Apagar tudo',
      onConfirm: async () => {
        for (const s of ['transactions', 'categories', 'budgets', 'goals', 'recurring', 'settings', 'cards', 'card_purchases']) {
          await DB.clearStore(s);
        }
        await DB.seedDefaults();
        Modal.close();
        Fmt.toast('Dados apagados');
        App.navigate('dashboard');
      },
    });
  }

  return { render };
})());
