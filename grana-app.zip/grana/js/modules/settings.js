/* settings.js — configurações: backup, restauração, notificações */
App.register('settings', (function () {
  async function render(container) {
    const { el } = Fmt;
    const wrap = el('div', { class: 'screen settings' });
    wrap.appendChild(el('h2', {}, 'Configurações'));

    // Backup manual
    const backupCard = el('div', { class: 'card' });
    backupCard.appendChild(el('div', { class: 'card-title' }, 'Backup'));
    backupCard.appendChild(el('p', { class: 'muted' }, 'O app salva um backup automático localmente todos os dias. Você também pode baixar ou restaurar um backup manualmente.'));
    backupCard.appendChild(el('div', { class: 'row-buttons' }, [
      el('button', { class: 'btn-secondary', onclick: downloadBackup }, '⬇️ Baixar backup (.json)'),
      el('button', { class: 'btn-secondary', onclick: triggerRestore }, '⬆️ Restaurar backup'),
    ]));
    const fileInput = el('input', { type: 'file', accept: 'application/json', id: 'restore-input', style: 'display:none' });
    fileInput.addEventListener('change', handleRestoreFile);
    backupCard.appendChild(fileInput);
    wrap.appendChild(backupCard);

    // Notificações
    const notifCard = el('div', { class: 'card' });
    notifCard.appendChild(el('div', { class: 'card-title' }, 'Notificações de vencimento'));
    const status = ('Notification' in window) ? Notification.permission : 'unsupported';
    notifCard.appendChild(el('p', { class: 'muted' },
      status === 'granted' ? 'Notificações ativadas ✅' :
      status === 'unsupported' ? 'Seu navegador não suporta notificações.' :
      'Ative para ser avisado sobre contas próximas do vencimento.'));
    if (status !== 'granted' && status !== 'unsupported') {
      notifCard.appendChild(el('button', {
        class: 'btn-primary small',
        onclick: async () => { await Notifications.requestPermission(); App.navigate('settings'); },
      }, 'Ativar notificações'));
    }
    wrap.appendChild(notifCard);

    // Sobre
    const aboutCard = el('div', { class: 'card' });
    aboutCard.appendChild(el('div', { class: 'card-title' }, 'Sobre o Grana'));
    aboutCard.appendChild(el('p', { class: 'muted' }, 'Grana é um app de controle financeiro pessoal que funciona 100% offline, com todos os dados guardados apenas no seu dispositivo.'));
    wrap.appendChild(aboutCard);

    // Zona de risco
    const dangerCard = el('div', { class: 'card' });
    dangerCard.appendChild(el('div', { class: 'card-title' }, 'Zona de risco'));
    dangerCard.appendChild(el('button', { class: 'btn-danger', onclick: confirmWipe }, 'Apagar todos os dados'));
    wrap.appendChild(dangerCard);

    container.appendChild(wrap);
  }

  async function downloadBackup() {
    const data = await DB.exportAllData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `grana-backup-${Fmt.todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    Fmt.toast('Backup baixado');
  }

  function triggerRestore() {
    document.getElementById('restore-input').click();
  }

  function handleRestoreFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const data = JSON.parse(reader.result);
        Modal.open({
          title: 'Restaurar backup',
          body: '<p>Isso vai substituir todos os dados atuais pelos dados do arquivo selecionado. Deseja continuar?</p>',
          confirmLabel: 'Restaurar',
          onConfirm: async () => {
            await DB.importAllData(data);
            Modal.close();
            Fmt.toast('Backup restaurado');
            App.navigate('dashboard');
          },
        });
      } catch (err) {
        Fmt.toast('Arquivo inválido');
      }
    };
    reader.readAsText(file);
  }

  function confirmWipe() {
    Modal.open({
      title: 'Apagar todos os dados',
      body: '<p>Essa ação não pode ser desfeita. Todas as transações, categorias, metas e recorrências serão apagadas permanentemente.</p>',
      confirmLabel: 'Apagar tudo',
      onConfirm: async () => {
        for (const s of ['transactions', 'categories', 'budgets', 'goals', 'recurring', 'settings']) {
          await DB.clearStore(s);
        }
        await DB.seedDefaults();
        Modal.close();
        Fmt.toast('Dados apagados');
        App.navigate('dashboard');
      },
    });
  }

  return { render };
})());
