/* goals.js — metas de economia */
App.register('goals', (function () {
  async function render(container) {
    const { el } = Fmt;
    const goals = await DB.all('goals');

    const wrap = el('div', { class: 'screen goals' });
    wrap.appendChild(el('div', { class: 'top-row' }, [
      el('h2', {}, 'Metas de economia'),
      el('button', { class: 'btn-primary small', onclick: () => openGoalModal(null) }, '+ Nova meta'),
    ]));

    if (goals.length === 0) {
      wrap.appendChild(el('p', { class: 'muted center' }, 'Você ainda não criou metas. Que tal começar uma reserva de emergência?'));
    }

    for (const g of goals) wrap.appendChild(goalCard(g));

    container.appendChild(wrap);
  }

  function goalCard(g) {
    const { el } = Fmt;
    const pct = Math.min(100, Math.round((g.saved / g.target) * 100));
    const card = el('div', { class: 'card goal-card' });
    card.appendChild(el('div', { class: 'card-title-row' }, [
      el('div', { class: 'card-title' }, `${g.icon || '🎯'} ${g.name}`),
      el('button', { class: 'link-btn', onclick: () => openGoalModal(g) }, 'Editar'),
    ]));
    card.appendChild(el('div', { class: 'progress-track' }, [
      el('div', { class: 'progress-fill goal', style: `width:${pct}%` }),
    ]));
    card.appendChild(el('div', { class: 'budget-row' }, [
      el('span', {}, `${Fmt.money(g.saved)} de ${Fmt.money(g.target)}`),
      el('span', { class: 'pos-text' }, `${pct}%`),
    ]));
    if (g.deadline) card.appendChild(el('div', { class: 'muted small' }, `Prazo: ${Fmt.dateBR(g.deadline)}`));
    card.appendChild(el('div', { class: 'row-buttons' }, [
      el('button', { class: 'btn-secondary small', onclick: () => addToGoal(g, 1) }, '+ Adicionar valor'),
    ]));
    return card;
  }

  function addToGoal(g, sign) {
    Modal.open({
      title: 'Adicionar valor à meta',
      body: `
        <label class="field-label">Valor a adicionar</label>
        <input type="number" step="0.01" id="goal-add" class="input" placeholder="0,00" />
      `,
      onConfirm: async () => {
        const val = parseFloat(document.getElementById('goal-add').value);
        if (!val) return Fmt.toast('Informe um valor');
        g.saved = (g.saved || 0) + val * sign;
        await DB.put('goals', g);
        Modal.close();
        Fmt.toast('Meta atualizada');
        App.navigate('goals');
      },
    });
  }

  function openGoalModal(existing) {
    const isEdit = !!existing;
    const g = existing || { name: '', target: '', saved: 0, deadline: '', icon: '🎯' };
    Modal.open({
      title: isEdit ? 'Editar meta' : 'Nova meta',
      body: `
        <label class="field-label">Nome da meta</label>
        <input type="text" id="goal-name" class="input" value="${g.name}" placeholder="Ex: Reserva de emergência" />
        <label class="field-label">Ícone (emoji)</label>
        <input type="text" id="goal-icon" class="input" value="${g.icon}" maxlength="2" />
        <label class="field-label">Valor alvo</label>
        <input type="number" step="0.01" id="goal-target" class="input" value="${g.target}" placeholder="0,00" />
        <label class="field-label">Já economizado</label>
        <input type="number" step="0.01" id="goal-saved" class="input" value="${g.saved}" placeholder="0,00" />
        <label class="field-label">Prazo (opcional)</label>
        <input type="date" id="goal-deadline" class="input" value="${g.deadline || ''}" />
      `,
      confirmLabel: isEdit ? 'Salvar' : 'Criar meta',
      onConfirm: async () => {
        const name = document.getElementById('goal-name').value.trim();
        const target = parseFloat(document.getElementById('goal-target').value);
        if (!name || !target) return Fmt.toast('Preencha nome e valor alvo');
        const record = {
          name,
          icon: document.getElementById('goal-icon').value.trim() || '🎯',
          target,
          saved: parseFloat(document.getElementById('goal-saved').value) || 0,
          deadline: document.getElementById('goal-deadline').value,
        };
        if (isEdit) record.id = existing.id;
        await DB.put('goals', record);
        Modal.close();
        Fmt.toast(isEdit ? 'Meta atualizada' : 'Meta criada');
        App.navigate('goals');
      },
    });
    if (isEdit) {
      const modalActions = document.querySelector('.modal-actions');
      const delBtn = Fmt.el('button', { class: 'btn-danger' }, 'Excluir');
      delBtn.addEventListener('click', async () => {
        await DB.remove('goals', existing.id);
        Modal.close();
        Fmt.toast('Meta excluída');
        App.navigate('goals');
      });
      modalActions.prepend(delBtn);
    }
  }

  return { render };
})());
