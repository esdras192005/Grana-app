/* reports.js — relatórios, gráficos de evolução e exportação */
App.register('reports', (function () {
  async function render(container) {
    const { el } = Fmt;
    const categories = await DB.all('categories');
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));
    const allItems = await DB.getAllSorted();

    const wrap = el('div', { class: 'screen reports' });
    wrap.appendChild(el('h2', {}, 'Relatórios'));

    // Evolução dos últimos 6 meses
    const months = [];
    let ym = App.currentMonth();
    for (let i = 0; i < 6; i++) { months.unshift(ym); ym = Fmt.shiftMonth(ym, -1); }
    const monthlyTotals = [];
    for (const m of months) monthlyTotals.push(await DB.computeMonthTotals(m));

    const card = el('div', { class: 'card' });
    card.appendChild(el('div', { class: 'card-title' }, 'Receitas x despesas (últimos 6 meses)'));
    card.appendChild(el('canvas', { id: 'trend-chart', height: '200' }));
    wrap.appendChild(card);

    // Exportação
    const exportCard = el('div', { class: 'card' });
    exportCard.appendChild(el('div', { class: 'card-title' }, 'Exportar transações'));
    exportCard.appendChild(el('p', { class: 'muted' }, 'Exporta todas as transações registradas no app.'));
    exportCard.appendChild(el('div', { class: 'row-buttons' }, [
      el('button', { class: 'btn-secondary', onclick: async () => {
        Fmt.toast('Gerando Excel...');
        await ExportUtil.toExcel(allItems, categories);
      } }, '📊 Exportar Excel'),
      el('button', { class: 'btn-secondary', onclick: async () => {
        Fmt.toast('Gerando PDF...');
        await ExportUtil.toPDF(allItems, categories, { subtitle: `Gerado em ${Fmt.dateBR(Fmt.todayISO())}` });
      } }, '📄 Exportar PDF'),
    ]));
    wrap.appendChild(exportCard);

    container.appendChild(wrap);

    renderTrendChart(months, monthlyTotals);
  }

  function renderTrendChart(months, totals) {
    const canvas = document.getElementById('trend-chart');
    if (!canvas || !window.Chart) return;
    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: months.map(m => Fmt.monthLabel(m).split(' de ')[0].slice(0, 3)),
        datasets: [
          { label: 'Receitas', data: totals.map(t => t.receitas), backgroundColor: '#00D9A3' },
          { label: 'Despesas', data: totals.map(t => t.despesas), backgroundColor: '#FF6B6B' },
        ],
      },
      options: {
        maintainAspectRatio: false,
        scales: {
          x: { ticks: { color: '#8A95A5' }, grid: { display: false } },
          y: { ticks: { color: '#8A95A5' }, grid: { color: '#232E3D' } },
        },
        plugins: { legend: { labels: { color: '#EDF2F7' } } },
      },
    });
  }

  return { render };
})());
