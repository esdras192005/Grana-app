/* calendar.js — calendário financeiro mensal */
App.register('calendar', (function () {
  let viewMonth = App.currentMonth();

  async function render(container) {
    const { el } = Fmt;
    const items = await DB.getTransactionsByMonth(viewMonth);
    const categories = await DB.all('categories');
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));

    const byDay = {};
    for (const t of items) {
      byDay[t.date] = byDay[t.date] || { receita: 0, despesa: 0, items: [] };
      byDay[t.date][t.type] += t.amount;
      byDay[t.date].items.push(t);
    }

    const wrap = el('div', { class: 'screen calendar' });
    wrap.appendChild(el('h2', {}, 'Calendário financeiro'));
    wrap.appendChild(el('div', { class: 'month-switch' }, [
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, -1); render(container); } }, '‹'),
      el('div', { class: 'month-switch-label' }, Fmt.monthLabel(viewMonth)),
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, 1); render(container); } }, '›'),
    ]));

    const weekDays = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
    const grid = el('div', { class: 'cal-grid' });
    for (const w of weekDays) grid.appendChild(el('div', { class: 'cal-weekday' }, w));

    const [y, m] = viewMonth.split('-').map(Number);
    const firstDay = new Date(y, m - 1, 1).getDay();
    const totalDays = Fmt.daysInMonth(viewMonth);

    for (let i = 0; i < firstDay; i++) grid.appendChild(el('div', { class: 'cal-cell empty' }));

    for (let d = 1; d <= totalDays; d++) {
      const dateStr = `${viewMonth}-${String(d).padStart(2, '0')}`;
      const day = byDay[dateStr];
      const isToday = dateStr === Fmt.todayISO();
      const cell = el('div', { class: `cal-cell ${isToday ? 'today' : ''} ${day ? 'has-data' : ''}` });
      cell.appendChild(el('div', { class: 'cal-day-num' }, String(d)));
      if (day) {
        if (day.receita) cell.appendChild(el('div', { class: 'cal-dot pos' }));
        if (day.despesa) cell.appendChild(el('div', { class: 'cal-dot neg' }));
      }
      if (day) cell.addEventListener('click', () => openDayModal(dateStr, day, catMap));
      grid.appendChild(cell);
    }
    wrap.appendChild(grid);

    wrap.appendChild(el('div', { class: 'legend-inline' }, [
      el('span', {}, [el('span', { class: 'cal-dot pos' }), ' Receita']),
      el('span', {}, [el('span', { class: 'cal-dot neg' }), ' Despesa']),
    ]));

    container.appendChild(wrap);
  }

  function openDayModal(dateStr, day, catMap) {
    const rows = day.items.map(t => {
      const cat = catMap[t.categoryId] || { name: 'Outros', icon: '📦' };
      return `<div class="cat-row">
        <span>${cat.icon} ${t.description || cat.name}</span>
        <span class="${t.type === 'receita' ? 'pos-text' : 'neg-text'}">${t.type === 'receita' ? '+' : '-'} ${Fmt.moneyCompact(t.amount)}</span>
      </div>`;
    }).join('');

    Modal.open({
      title: Fmt.dateBR(dateStr),
      body: `<div class="cat-list">${rows}</div>`,
      hideConfirm: true,
      cancelLabel: 'Fechar',
    });
  }

  return { render };
})());
