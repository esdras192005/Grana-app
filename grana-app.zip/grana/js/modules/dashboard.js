/* dashboard.js — tela inicial: resumo financeiro */
App.register('dashboard', (function () {
  let viewMonth = App.currentMonth();

  async function render(container) {
    const { el } = Fmt;
    const saldo = await DB.computeBalance();
    const { receitas, despesas, byCategory } = await DB.computeMonthTotals(viewMonth);
    const budgetRec = await DB.get('budgets', `orcamento:${viewMonth}`);
    const orcamento = budgetRec ? budgetRec.amount : null;
    const restante = orcamento != null ? orcamento - despesas : null;
    const categories = await DB.all('categories');
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));

    const wrap = el('div', { class: 'screen dashboard' });

    // Header com saldo
    wrap.appendChild(el('div', { class: 'hero-card' }, [
      el('div', { class: 'hero-label' }, 'Saldo atual'),
      el('div', {
        class: `hero-value ${saldo < 0 ? 'neg' : ''}`,
        onclick: () => App.modules.transactions.openAdjustBalance(),
      }, Fmt.money(saldo)),
      el('div', { class: 'hero-sub' }, `Toque no valor para ajustar · ${Fmt.monthLabel(viewMonth)}`),
    ]));

    // Seletor de mês
    wrap.appendChild(el('div', { class: 'month-switch' }, [
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, -1); render(container); } }, '‹'),
      el('div', { class: 'month-switch-label' }, Fmt.monthLabel(viewMonth)),
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, 1); render(container); } }, '›'),
    ]));

    // Cards de indicadores
    const grid = el('div', { class: 'stat-grid' });
    grid.appendChild(statCard('Recebido no mês', receitas, 'up'));
    grid.appendChild(statCard('Gasto no mês', despesas, 'down'));
    wrap.appendChild(grid);

    // Orçamento
    wrap.appendChild(renderBudgetCard(orcamento, despesas, restante, viewMonth));

    // Cartões de crédito
    wrap.appendChild(await renderCardsSummary());

    // Para onde o dinheiro está indo (top categorias)
    const catBudgets = await DB.getCategoryBudgets(viewMonth);
    wrap.appendChild(renderCategoryBreakdown(byCategory, catMap, despesas, catBudgets));

    // Próximos vencimentos
    wrap.appendChild(await renderUpcoming());

    container.appendChild(wrap);

    renderDonutChart(byCategory, catMap);
  }

  function statCard(label, value, dir) {
    const { el } = Fmt;
    return el('div', { class: 'stat-card' }, [
      el('div', { class: 'stat-label' }, label),
      el('div', { class: `stat-value ${dir}` }, Fmt.money(value)),
    ]);
  }

  function renderBudgetCard(orcamento, despesas, restante, ym) {
    const { el } = Fmt;
    const card = el('div', { class: 'card budget-card' });
    if (orcamento == null) {
      card.appendChild(el('div', { class: 'card-title-row' }, [
        el('div', { class: 'card-title' }, 'Orçamento do mês'),
        el('button', { class: 'link-btn', onclick: () => openCategoryBudgetModal(ym) }, 'Por categoria'),
      ]));
      card.appendChild(el('p', { class: 'muted' }, 'Defina um orçamento para saber quanto ainda pode gastar.'));
      card.appendChild(el('button', {
        class: 'btn-secondary',
        onclick: () => openBudgetModal(ym),
      }, 'Definir orçamento total'));
      return card;
    }
    const pct = Math.min(100, Math.round((despesas / orcamento) * 100));
    const over = despesas > orcamento;
    card.appendChild(el('div', { class: 'card-title-row' }, [
      el('div', { class: 'card-title' }, 'Orçamento do mês'),
      el('div', {}, [
        el('button', { class: 'link-btn', onclick: () => openCategoryBudgetModal(ym) }, 'Por categoria'),
        el('button', { class: 'link-btn', onclick: () => openBudgetModal(ym) }, 'Editar'),
      ]),
    ]));
    card.appendChild(el('div', { class: 'progress-track' }, [
      el('div', { class: `progress-fill ${over ? 'over' : ''}`, style: `width:${pct}%` }),
    ]));
    card.appendChild(el('div', { class: 'budget-row' }, [
      el('span', {}, `${Fmt.money(despesas)} de ${Fmt.money(orcamento)}`),
      el('span', { class: over ? 'neg-text' : 'pos-text' },
        over ? `${Fmt.money(Math.abs(restante))} acima` : `${Fmt.money(restante)} livre`),
    ]));
    return card;
  }

  function openBudgetModal(ym) {
    Modal.open({
      title: 'Orçamento total do mês',
      body: `
        <label class="field-label">Valor do orçamento para ${Fmt.monthLabel(ym)}</label>
        <input type="number" step="0.01" id="budget-input" class="input" placeholder="0,00" />
      `,
      onConfirm: async () => {
        const val = parseFloat(document.getElementById('budget-input').value);
        if (!val || val <= 0) return Fmt.toast('Informe um valor válido');
        await DB.put('budgets', { id: `orcamento:${ym}`, amount: val, month: ym });
        Modal.close();
        App.navigate('dashboard');
        Fmt.toast('Orçamento salvo');
      },
    });
  }

  async function openCategoryBudgetModal(ym) {
    const categories = (await DB.all('categories')).filter(c => c.type === 'despesa' && c.name !== 'Ajuste de saldo');
    const existing = await DB.getCategoryBudgets(ym);
    const budgetMap = Object.fromEntries(existing.map(b => [b.categoryId, b.amount]));

    const rows = categories.map(c => `
      <div class="cat-budget-row">
        <span>${c.icon} ${c.name}</span>
        <input type="number" step="0.01" class="input cat-budget-input" data-cat="${c.id}" value="${budgetMap[c.id] || ''}" placeholder="0,00" />
      </div>
    `).join('');

    Modal.open({
      title: `Orçamento por categoria — ${Fmt.monthLabel(ym)}`,
      body: `<div class="cat-list">${rows}</div>`,
      confirmLabel: 'Salvar',
      onConfirm: async () => {
        const inputs = document.querySelectorAll('.cat-budget-input');
        for (const input of inputs) {
          const val = parseFloat(input.value);
          const catId = isNaN(Number(input.dataset.cat)) ? input.dataset.cat : Number(input.dataset.cat);
          if (val && val > 0) await DB.setCategoryBudget(catId, ym, val);
        }
        Modal.close();
        Fmt.toast('Orçamentos salvos');
        App.navigate('dashboard');
      },
    });
  }

  async function renderCardsSummary() {
    const { el } = Fmt;
    const cards = await DB.all('cards');
    const card = el('div', { class: 'card' });
    card.appendChild(el('div', { class: 'card-title-row' }, [
      el('div', { class: 'card-title' }, '💳 Cartões de crédito'),
      el('button', { class: 'link-btn', onclick: () => App.navigate('cards') }, cards.length ? 'Ver tudo' : '+ Adicionar'),
    ]));
    if (cards.length === 0) {
      card.appendChild(el('p', { class: 'muted' }, 'Nenhum cartão cadastrado.'));
      return card;
    }
    const ym = App.currentMonth();
    let total = 0;
    for (const c of cards) total += await DB.computeInvoiceTotal(c.id, ym);
    card.appendChild(el('div', { class: 'budget-row' }, [
      el('span', {}, `Faturas abertas de ${Fmt.monthLabel(ym)}`),
      el('span', { class: 'neg-text' }, Fmt.money(total)),
    ]));
    return card;
  }

  function renderCategoryBreakdown(byCategory, catMap, despesas, catBudgets) {
    const { el } = Fmt;
    const budgetMap = Object.fromEntries((catBudgets || []).map(b => [String(b.categoryId), b.amount]));
    const card = el('div', { class: 'card' });
    card.appendChild(el('div', { class: 'card-title' }, 'Para onde seu dinheiro está indo'));
    card.appendChild(el('canvas', { id: 'donut-chart', height: '180' }));

    const entries = Object.entries(byCategory).sort((a, b) => b[1] - a[1]).slice(0, 6);
    if (entries.length === 0) {
      card.appendChild(el('p', { class: 'muted' }, 'Nenhuma despesa registrada neste mês.'));
      return card;
    }
    const list = el('div', { class: 'legend-list' });
    for (const [catId, val] of entries) {
      const cat = catMap[catId] || { name: 'Outros', color: '#8A95A5', icon: '📦' };
      const pct = despesas ? Math.round((val / despesas) * 100) : 0;
      list.appendChild(el('div', { class: 'legend-row' }, [
        el('span', { class: 'legend-dot', style: `background:${cat.color}` }),
        el('span', { class: 'legend-name' }, `${cat.icon} ${cat.name}`),
        el('span', { class: 'legend-pct' }, `${pct}%`),
        el('span', { class: 'legend-val' }, Fmt.money(val)),
      ]));
      const catBudget = budgetMap[String(catId)];
      if (catBudget) {
        const catPct = Math.min(100, Math.round((val / catBudget) * 100));
        const over = val > catBudget;
        list.appendChild(el('div', { class: 'cat-budget-bar-row' }, [
          el('div', { class: 'progress-track thin' }, [
            el('div', { class: `progress-fill ${over ? 'over' : ''}`, style: `width:${catPct}%` }),
          ]),
          el('span', { class: `muted small ${over ? 'neg-text' : ''}` }, `${Fmt.moneyCompact(val)} / ${Fmt.moneyCompact(catBudget)}`),
        ]));
      }
    }
    card.appendChild(list);
    return card;
  }

  function renderDonutChart(byCategory, catMap) {
    const canvas = document.getElementById('donut-chart');
    if (!canvas || !window.Chart) return;
    const entries = Object.entries(byCategory).sort((a, b) => b[1] - a[1]);
    const labels = entries.map(([id]) => (catMap[id] ? catMap[id].name : 'Outros'));
    const data = entries.map(([, v]) => v);
    const colors = entries.map(([id]) => (catMap[id] ? catMap[id].color : '#8A95A5'));
    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(canvas, {
      type: 'doughnut',
      data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 0 }] },
      options: {
        cutout: '68%',
        plugins: { legend: { display: false } },
        maintainAspectRatio: false,
      },
    });
  }

  async function renderUpcoming() {
    const { el } = Fmt;
    const recs = (await DB.all('recurring')).filter(r => r.active);
    recs.sort((a, b) => a.nextDate < b.nextDate ? -1 : 1);
    const card = el('div', { class: 'card' });
    card.appendChild(el('div', { class: 'card-title' }, 'Próximos vencimentos'));
    if (recs.length === 0) {
      card.appendChild(el('p', { class: 'muted' }, 'Nenhuma conta recorrente cadastrada.'));
      return card;
    }
    for (const r of recs.slice(0, 4)) {
      const row = el('div', { class: 'upcoming-row' }, [
        el('span', {}, `${r.isSubscription ? '📺' : '🔁'} ${r.description}`),
        el('span', { class: 'muted' }, Fmt.dateBR(r.nextDate)),
        el('span', { class: 'neg-text' }, Fmt.moneyCompact(r.amount)),
      ]);
      const payBtn = el('button', { class: 'link-btn' }, '✅ Pago');
      payBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await DB.markRecurringPaid(r.id);
        Fmt.toast('Marcado como pago');
        App.navigate('dashboard');
      });
      row.appendChild(payBtn);
      card.appendChild(row);
    }
    return card;
  }

  return { render };
})());
