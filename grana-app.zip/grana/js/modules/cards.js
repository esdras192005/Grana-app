/* cards.js — cartões de crédito, faturas e compras parceladas */
App.register('cards', (function () {
  let selectedCardId = null;
  let viewMonth = App.currentMonth();

  async function render(container) {
    if (selectedCardId != null) return renderDetail(container);
    return renderList(container);
  }

  async function renderList(container) {
    const { el } = Fmt;
    const cards = await DB.all('cards');
    const wrap = el('div', { class: 'screen cards-screen' });

    wrap.appendChild(el('div', { class: 'top-row' }, [
      el('button', { class: 'link-btn', onclick: () => App.navigate('dashboard') }, '‹ Início'),
      el('button', { class: 'btn-primary small', onclick: () => openCardModal() }, '+ Novo cartão'),
    ]));
    wrap.appendChild(el('h2', {}, '💳 Cartões de crédito'));

    if (cards.length === 0) {
      wrap.appendChild(el('p', { class: 'muted center' }, 'Nenhum cartão cadastrado ainda.'));
    }

    for (const card of cards) {
      const ym = App.currentMonth();
      const total = await DB.computeInvoiceTotal(card.id, ym);
      const paid = await DB.isInvoicePaid(card.id, ym);
      const c = el('div', { class: 'card card-tile' });
      c.appendChild(el('div', { class: 'card-title-row' }, [
        el('div', { class: 'card-title' }, `${card.icon || '💳'} ${card.name}`),
        el('span', { class: paid ? 'pos-text' : 'neg-text' }, paid ? 'Fatura paga' : Fmt.money(total)),
      ]));
      c.appendChild(el('div', { class: 'muted small' }, `Fecha dia ${card.closingDay} · Vence dia ${card.dueDay}`));
      c.addEventListener('click', () => { selectedCardId = card.id; viewMonth = App.currentMonth(); App.navigate('cards'); });
      wrap.appendChild(c);
    }

    container.appendChild(wrap);
  }

  async function renderDetail(container) {
    const { el } = Fmt;
    const card = await DB.get('cards', selectedCardId);
    if (!card) { selectedCardId = null; return renderList(container); }

    const purchases = await DB.getInvoicePurchases(card.id, viewMonth);
    const total = await DB.computeInvoiceTotal(card.id, viewMonth);
    const paid = await DB.isInvoicePaid(card.id, viewMonth);
    const categories = await DB.all('categories');
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));

    const wrap = el('div', { class: 'screen cards-screen' });
    wrap.appendChild(el('button', { class: 'link-btn', onclick: () => { selectedCardId = null; App.navigate('cards'); } }, '‹ Cartões'));
    wrap.appendChild(el('h2', {}, `${card.icon || '💳'} ${card.name}`));

    wrap.appendChild(el('div', { class: 'month-switch' }, [
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, -1); render(container); } }, '‹'),
      el('div', { class: 'month-switch-label' }, Fmt.monthLabel(viewMonth)),
      el('button', { class: 'icon-btn', onclick: () => { viewMonth = Fmt.shiftMonth(viewMonth, 1); render(container); } }, '›'),
    ]));

    const invoiceCard = el('div', { class: 'card' });
    invoiceCard.appendChild(el('div', { class: 'card-title-row' }, [
      el('div', { class: 'card-title' }, 'Fatura do mês'),
      el('span', { class: paid ? 'pos-text' : 'neg-text' }, paid ? '✅ Paga' : '⏳ Aberta'),
    ]));
    invoiceCard.appendChild(el('div', { class: 'hero-value', style: 'font-size:24px;margin-bottom:10px' }, Fmt.money(total)));
    if (!paid && total > 0) {
      const payBtn = el('button', { class: 'btn-primary small' }, '✅ Marcar fatura como paga');
      payBtn.addEventListener('click', async () => {
        Modal.open({
          title: 'Pagar fatura',
          body: `<p>Isso vai lançar uma despesa de <strong>${Fmt.money(total)}</strong> no seu saldo, referente à fatura de ${Fmt.monthLabel(viewMonth)} do cartão ${card.name}.</p>`,
          confirmLabel: 'Confirmar pagamento',
          onConfirm: async () => {
            await DB.payInvoice(card.id, viewMonth);
            Modal.close();
            Fmt.toast('Fatura paga');
            App.navigate('cards');
          },
        });
      });
      invoiceCard.appendChild(payBtn);
    }
    wrap.appendChild(invoiceCard);

    wrap.appendChild(el('button', { class: 'btn-secondary', onclick: () => openPurchaseModal(card, categories) }, '+ Nova compra no cartão'));

    const list = el('div', { class: 'tx-list', style: 'margin-top:12px' });
    if (purchases.length === 0) {
      list.appendChild(el('p', { class: 'muted center' }, 'Nenhuma compra nessa fatura.'));
    } else {
      for (const p of purchases) {
        const cat = catMap[p.categoryId] || { name: 'Outros', icon: '📦', color: '#8A95A5' };
        list.appendChild(el('div', { class: 'tx-row' }, [
          el('div', { class: 'tx-icon', style: `background:${cat.color}22;color:${cat.color}` }, cat.icon),
          el('div', { class: 'tx-info' }, [
            el('div', { class: 'tx-desc' }, p.description),
            el('div', { class: 'tx-meta muted' }, `${cat.name} · ${Fmt.dateBR(p.date)}`),
          ]),
          el('div', { class: 'tx-amount neg-text' }, Fmt.moneyCompact(p.amount)),
        ]));
      }
    }
    wrap.appendChild(list);

    container.appendChild(wrap);
  }

  function openCardModal() {
    Modal.open({
      title: 'Novo cartão',
      body: `
        <label class="field-label">Nome do cartão</label>
        <input type="text" id="card-name" class="input" placeholder="Ex: Nubank" />
        <label class="field-label">Ícone (emoji)</label>
        <input type="text" id="card-icon" class="input" value="💳" maxlength="2" />
        <div class="row-2-even">
          <div>
            <label class="field-label">Dia de fechamento</label>
            <input type="number" min="1" max="31" id="card-closing" class="input" placeholder="Ex: 25" />
          </div>
          <div>
            <label class="field-label">Dia de vencimento</label>
            <input type="number" min="1" max="31" id="card-due" class="input" placeholder="Ex: 5" />
          </div>
        </div>
        <label class="field-label">Limite (opcional)</label>
        <input type="number" step="0.01" id="card-limit" class="input" placeholder="0,00" />
      `,
      confirmLabel: 'Criar cartão',
      onConfirm: async () => {
        const name = document.getElementById('card-name').value.trim();
        const closingDay = parseInt(document.getElementById('card-closing').value, 10);
        const dueDay = parseInt(document.getElementById('card-due').value, 10);
        if (!name || !closingDay || !dueDay) return Fmt.toast('Preencha nome, fechamento e vencimento');
        await DB.put('cards', {
          name,
          icon: document.getElementById('card-icon').value.trim() || '💳',
          closingDay, dueDay,
          limit: parseFloat(document.getElementById('card-limit').value) || null,
        });
        Modal.close();
        Fmt.toast('Cartão criado');
        App.navigate('cards');
      },
    });
  }

  function openPurchaseModal(card, categories) {
    const catOptions = categories.filter(c => c.type === 'despesa' && c.name !== 'Ajuste de saldo').map(c =>
      `<option value="${c.id}">${c.icon} ${c.name}</option>`
    ).join('');

    Modal.open({
      title: `Nova compra — ${card.name}`,
      body: `
        <label class="field-label">Descrição</label>
        <input type="text" id="pur-desc" class="input" placeholder="Ex: Tênis novo" />
        <label class="field-label">Valor total</label>
        <input type="number" step="0.01" id="pur-amount" class="input" placeholder="0,00" />
        <label class="field-label">Categoria</label>
        <select id="pur-category" class="input">${catOptions}</select>
        <label class="field-label">Data da compra</label>
        <input type="date" id="pur-date" class="input" value="${Fmt.todayISO()}" />
        <label class="field-label">Número de parcelas</label>
        <input type="number" min="1" max="36" id="pur-installments" class="input" value="1" />
      `,
      confirmLabel: 'Lançar compra',
      onConfirm: async () => {
        const description = document.getElementById('pur-desc').value.trim();
        const totalAmount = parseFloat(document.getElementById('pur-amount').value);
        if (!description || !totalAmount) return Fmt.toast('Preencha descrição e valor');
        await DB.addCardPurchase({
          cardId: card.id,
          date: document.getElementById('pur-date').value,
          description,
          totalAmount,
          categoryId: document.getElementById('pur-category').value,
          installments: document.getElementById('pur-installments').value,
        });
        Modal.close();
        Fmt.toast('Compra lançada');
        App.navigate('cards');
      },
    });
  }

  return { render };
})());
