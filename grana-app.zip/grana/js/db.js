/* db.js — camada de dados (IndexedDB) do Grana
   Stores: transactions, categories, budgets, goals, recurring, settings, backups
*/
window.DB = (function () {
  const DB_NAME = 'grana-db';
  const DB_VERSION = 1;
  let dbInstance = null;

  function open() {
    return new Promise((resolve, reject) => {
      if (dbInstance) return resolve(dbInstance);
      const req = indexedDB.open(DB_NAME, DB_VERSION);

      req.onupgradeneeded = (e) => {
        const db = e.target.result;

        if (!db.objectStoreNames.contains('transactions')) {
          const t = db.createObjectStore('transactions', { keyPath: 'id', autoIncrement: true });
          t.createIndex('date', 'date');
          t.createIndex('type', 'type');
          t.createIndex('categoryId', 'categoryId');
        }
        if (!db.objectStoreNames.contains('categories')) {
          db.createObjectStore('categories', { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains('budgets')) {
          // keyPath = "YYYY-MM" para orçamento mensal, ou "categoryId:YYYY-MM"
          db.createObjectStore('budgets', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('goals')) {
          db.createObjectStore('goals', { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains('recurring')) {
          db.createObjectStore('recurring', { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains('backups')) {
          db.createObjectStore('backups', { keyPath: 'id', autoIncrement: true });
        }
      };

      req.onsuccess = (e) => { dbInstance = e.target.result; resolve(dbInstance); };
      req.onerror = (e) => reject(e.target.error);
    });
  }

  function tx(storeName, mode = 'readonly') {
    return open().then(db => db.transaction(storeName, mode).objectStore(storeName));
  }

  function all(storeName) {
    return tx(storeName).then(store => new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  }

  function get(storeName, key) {
    return tx(storeName).then(store => new Promise((resolve, reject) => {
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  }

  function put(storeName, value) {
    return tx(storeName, 'readwrite').then(store => new Promise((resolve, reject) => {
      const req = store.put(value);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }));
  }

  function remove(storeName, key) {
    return tx(storeName, 'readwrite').then(store => new Promise((resolve, reject) => {
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    }));
  }

  function clearStore(storeName) {
    return tx(storeName, 'readwrite').then(store => new Promise((resolve, reject) => {
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    }));
  }

  // ---------- Categorias padrão ----------
  const DEFAULT_CATEGORIES = [
    { name: 'Alimentação', icon: '🍔', color: '#FF8A5B', type: 'despesa' },
    { name: 'Combustível', icon: '⛽', color: '#F2C14E', type: 'despesa' },
    { name: 'Contas', icon: '🧾', color: '#5FA8D3', type: 'despesa' },
    { name: 'Lazer', icon: '🎮', color: '#B983FF', type: 'despesa' },
    { name: 'Saúde', icon: '💊', color: '#FF6B6B', type: 'despesa' },
    { name: 'Casa', icon: '🏠', color: '#8FBFA0', type: 'despesa' },
    { name: 'Transporte', icon: '🚌', color: '#4FD1C5', type: 'despesa' },
    { name: 'Educação', icon: '📚', color: '#6C8CFF', type: 'despesa' },
    { name: 'Outros', icon: '📦', color: '#8A95A5', type: 'despesa' },
    { name: 'Salário', icon: '💰', color: '#00D9A3', type: 'receita' },
    { name: 'Freelance', icon: '💻', color: '#00C2D9', type: 'receita' },
    { name: 'Outros', icon: '➕', color: '#00D9A3', type: 'receita' },
  ];

  async function seedDefaults() {
    const cats = await all('categories');
    if (cats.length === 0) {
      for (const c of DEFAULT_CATEGORIES) await put('categories', c);
    }
  }

  // ---------- Helpers de negócio ----------
  function monthKey(dateStr) { return dateStr.slice(0, 7); } // "YYYY-MM"

  async function getTransactionsByMonth(ym) {
    const items = await all('transactions');
    return items.filter(t => monthKey(t.date) === ym);
  }

  async function getAllSorted() {
    const items = await all('transactions');
    return items.sort((a, b) => (a.date < b.date ? 1 : -1));
  }

  async function computeBalance() {
    const items = await all('transactions');
    let saldo = 0;
    for (const t of items) saldo += t.type === 'receita' ? t.amount : -t.amount;
    return saldo;
  }

  async function computeMonthTotals(ym) {
    const items = await getTransactionsByMonth(ym);
    let receitas = 0, despesas = 0;
    const byCategory = {};
    for (const t of items) {
      if (t.type === 'receita') receitas += t.amount;
      else {
        despesas += t.amount;
        byCategory[t.categoryId] = (byCategory[t.categoryId] || 0) + t.amount;
      }
    }
    return { receitas, despesas, byCategory };
  }

  // ---------- Recorrências: gera lançamentos futuros já vencidos ----------
  async function processRecurring() {
    const recs = await all('recurring');
    const today = new Date().toISOString().slice(0, 10);
    for (const r of recs) {
      if (!r.active) continue;
      let next = r.nextDate;
      let created = false;
      while (next <= today) {
        await put('transactions', {
          date: next,
          type: r.type,
          amount: r.amount,
          categoryId: r.categoryId,
          description: r.description,
          recurringId: r.id,
          paid: false,
        });
        created = true;
        next = addInterval(next, r.frequency);
      }
      if (created) {
        r.nextDate = next;
        await put('recurring', r);
      }
    }
  }

  function addInterval(dateStr, frequency) {
    const d = new Date(dateStr + 'T00:00:00');
    if (frequency === 'mensal') d.setMonth(d.getMonth() + 1);
    else if (frequency === 'semanal') d.setDate(d.getDate() + 7);
    else if (frequency === 'anual') d.setFullYear(d.getFullYear() + 1);
    else if (frequency === 'quinzenal') d.setDate(d.getDate() + 15);
    return d.toISOString().slice(0, 10);
  }

  // ---------- Backup ----------
  async function exportAllData() {
    const stores = ['transactions', 'categories', 'budgets', 'goals', 'recurring', 'settings'];
    const data = {};
    for (const s of stores) data[s] = await all(s);
    data._meta = { app: 'grana', exportedAt: new Date().toISOString(), version: DB_VERSION };
    return data;
  }

  async function importAllData(data) {
    const stores = ['transactions', 'categories', 'budgets', 'goals', 'recurring', 'settings'];
    for (const s of stores) {
      if (!data[s]) continue;
      await clearStore(s);
      for (const item of data[s]) await put(s, item);
    }
  }

  return {
    open, all, get, put, remove, clearStore,
    seedDefaults, monthKey, getTransactionsByMonth, getAllSorted,
    computeBalance, computeMonthTotals, processRecurring, addInterval,
    exportAllData, importAllData,
  };
})();
