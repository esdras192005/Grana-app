/* app.js — núcleo do Grana: registro de módulos, roteador, inicialização */
window.App = (function () {
  const modules = {};
  let currentRoute = null;

  function register(name, mod) { modules[name] = mod; }

  function navigate(route) {
    currentRoute = route;
    document.querySelectorAll('.nav-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.route === route);
    });
    const container = document.getElementById('view');
    container.innerHTML = '';
    container.classList.remove('fade-in');
    const mod = modules[route];
    if (mod && mod.render) {
      mod.render(container);
      requestAnimationFrame(() => container.classList.add('fade-in'));
    }
    window.scrollTo(0, 0);
    location.hash = route;
  }

  function currentMonth() {
    return new Date().toISOString().slice(0, 7);
  }

  async function init() {
    await DB.open();
    await DB.seedDefaults();
    await DB.processRecurring();
    Notifications.checkUpcoming();

    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', () => navigate(btn.dataset.route));
    });

    const startRoute = (location.hash || '#dashboard').replace('#', '');
    navigate(modules[startRoute] ? startRoute : 'dashboard');

    // Backup automático silencioso ao abrir o app (uma vez por dia)
    maybeAutoBackup();
  }

  async function maybeAutoBackup() {
    const last = await DB.get('settings', 'lastAutoBackup');
    const today = new Date().toISOString().slice(0, 10);
    if (last && last.value === today) return;
    const data = await DB.exportAllData();
    await DB.put('backups', { createdAt: new Date().toISOString(), data });
    // mantém só os 5 backups automáticos mais recentes
    const all = await DB.all('backups');
    if (all.length > 5) {
      all.sort((a, b) => a.createdAt < b.createdAt ? -1 : 1);
      for (const old of all.slice(0, all.length - 5)) await DB.remove('backups', old.id);
    }
    await DB.put('settings', { key: 'lastAutoBackup', value: today });
  }

  return { register, navigate, currentMonth, init, get modules() { return modules; } };
})();

document.addEventListener('DOMContentLoaded', () => App.init());

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  });
}
