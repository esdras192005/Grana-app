/* export.js — exportação para Excel (.xlsx) e PDF */
window.ExportUtil = (function () {
  const XLSX_CDN = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
  const JSPDF_CDN = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      if (document.querySelector(`script[src="${src}"]`)) return resolve();
      const s = document.createElement('script');
      s.src = src;
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  function rowsFromTransactions(items, categories) {
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));
    return items.map(t => ({
      Data: Fmt.dateBR(t.date),
      Tipo: t.type === 'receita' ? 'Receita' : 'Despesa',
      Categoria: catMap[t.categoryId] ? catMap[t.categoryId].name : '—',
      Descrição: t.description || '',
      Valor: t.amount,
    }));
  }

  async function toExcel(items, categories, filename = 'grana-transacoes.xlsx') {
    await loadScript(XLSX_CDN);
    const rows = rowsFromTransactions(items, categories);
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Transações');
    XLSX.writeFile(wb, filename);
  }

  async function toPDF(items, categories, meta = {}, filename = 'grana-relatorio.pdf') {
    await loadScript(JSPDF_CDN);
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const catMap = Object.fromEntries(categories.map(c => [c.id, c]));

    doc.setFontSize(16);
    doc.text('Grana — Relatório Financeiro', 14, 18);
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(meta.subtitle || '', 14, 25);

    doc.setFontSize(9);
    doc.setTextColor(0);
    let y = 36;
    doc.setFont(undefined, 'bold');
    doc.text('Data', 14, y);
    doc.text('Tipo', 40, y);
    doc.text('Categoria', 65, y);
    doc.text('Descrição', 100, y);
    doc.text('Valor', 180, y, { align: 'right' });
    doc.setFont(undefined, 'normal');
    y += 5;
    doc.setDrawColor(200);
    doc.line(14, y - 3, 196, y - 3);

    for (const t of items) {
      if (y > 280) { doc.addPage(); y = 20; }
      const cat = catMap[t.categoryId] ? catMap[t.categoryId].name : '—';
      doc.text(Fmt.dateBR(t.date), 14, y);
      doc.text(t.type === 'receita' ? 'Receita' : 'Despesa', 40, y);
      doc.text(String(cat).slice(0, 18), 65, y);
      doc.text(String(t.description || '').slice(0, 30), 100, y);
      doc.text(Fmt.money(t.amount), 180, y, { align: 'right' });
      y += 6;
    }
    doc.save(filename);
  }

  return { toExcel, toPDF };
})();
