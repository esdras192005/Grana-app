/* notifications.js — alertas de vencimento (melhor esforço em PWA) */
window.Notifications = (function () {
  async function requestPermission() {
    if (!('Notification' in window)) return 'unsupported';
    if (Notification.permission === 'default') return await Notification.requestPermission();
    return Notification.permission;
  }

  function show(title, body) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      navigator.serviceWorker.ready.then(reg => reg.showNotification(title, {
        body, icon: './icons/icon-192.png', badge: './icons/icon-192.png',
      }));
    } else {
      new Notification(title, { body, icon: './icons/icon-192.png' });
    }
  }

  // Verifica contas recorrentes com vencimento nos próximos 3 dias, ao abrir o app
  async function checkUpcoming() {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const recs = await DB.all('recurring');
    const today = new Date();
    const limit = new Date();
    limit.setDate(limit.getDate() + 3);
    const shown = (await DB.get('settings', 'notifiedRecurring')) || { value: [] };
    const notified = new Set(shown.value);

    for (const r of recs) {
      if (!r.active) continue;
      const next = new Date(r.nextDate + 'T00:00:00');
      const key = `${r.id}:${r.nextDate}`;
      if (next >= today && next <= limit && !notified.has(key)) {
        show('Conta a vencer', `${r.description} — ${Fmt.money(r.amount)} em ${Fmt.dateBR(r.nextDate)}`);
        notified.add(key);
      }
    }
    await DB.put('settings', { key: 'notifiedRecurring', value: Array.from(notified) });
  }

  return { requestPermission, show, checkUpcoming };
})();
