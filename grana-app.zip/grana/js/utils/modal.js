/* modal.js — modal genérico reutilizável */
window.Modal = (function () {
  let overlay = null;

  function open({ title, body, confirmLabel = 'Salvar', cancelLabel = 'Cancelar', onConfirm, hideCancel = false, hideConfirm = false }) {
    close();
    overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <h3>${title}</h3>
          <button class="modal-close" aria-label="Fechar">✕</button>
        </div>
        <div class="modal-body">${body}</div>
        <div class="modal-actions">
          ${hideCancel ? '' : `<button class="btn-secondary modal-cancel">${cancelLabel}</button>`}
          ${hideConfirm ? '' : `<button class="btn-primary modal-confirm">${confirmLabel}</button>`}
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('show'));

    overlay.querySelector('.modal-close').addEventListener('click', close);
    const cancelBtn = overlay.querySelector('.modal-cancel');
    if (cancelBtn) cancelBtn.addEventListener('click', close);
    const confirmBtn = overlay.querySelector('.modal-confirm');
    if (confirmBtn && onConfirm) confirmBtn.addEventListener('click', onConfirm);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
  }

  function close() {
    if (overlay) { overlay.remove(); overlay = null; }
  }

  return { open, close };
})();
