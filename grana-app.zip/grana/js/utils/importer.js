/* importer.js — leitura de extratos bancários (CSV/OFX) e sugestão de categoria */
window.Importer = (function () {
  const KEYWORD_MAP = [
    { kw: ['uber', '99app', '99pop', 'taxi', 'onibus', 'ônibus', 'metro', 'metrô'], cat: 'Transporte' },
    { kw: ['ifood', 'rappi', 'restaurante', 'lanchonete', 'padaria'], cat: 'Alimentação' },
    { kw: ['supermercado', 'mercado', 'atacad', 'hortifruti', 'sacolao', 'sacolão'], cat: 'Alimentação' },
    { kw: ['posto', 'combustivel', 'combustível', 'ipiranga', 'shell', 'petrobras', 'br mania'], cat: 'Combustível' },
    { kw: ['farmacia', 'farmácia', 'drogaria', 'droga raia', 'pague menos'], cat: 'Saúde' },
    { kw: ['netflix', 'spotify', 'amazon prime', 'disney', 'hbo', 'youtube premium', 'icloud', 'google one', 'deezer'], cat: 'Assinaturas' },
    { kw: ['salario', 'salário', 'pagamento folha', 'proventos'], cat: 'Salário' },
    { kw: ['cinema', 'ingresso', 'steam', 'playstation', 'xbox', 'bar ', 'balada'], cat: 'Lazer' },
    { kw: ['escola', 'faculdade', 'curso', 'udemy', 'mensalidade'], cat: 'Educação' },
    { kw: ['aluguel', 'condominio', 'condomínio', 'energia', 'enel', 'cemig', 'copel', 'sabesp', 'internet', 'vivo', 'claro', 'tim ', 'telefone'], cat: 'Contas' },
  ];

  function guessCategoryId(description, categories, type) {
    const desc = (description || '').toLowerCase();
    for (const rule of KEYWORD_MAP) {
      if (rule.kw.some(k => desc.includes(k))) {
        const cat = categories.find(c => c.name === rule.cat && c.type === type);
        if (cat) return cat.id;
        const catAny = categories.find(c => c.name === rule.cat);
        if (catAny) return catAny.id;
      }
    }
    const fallback = categories.find(c => c.name === 'Outros' && c.type === type);
    if (fallback) return fallback.id;
    const anyOfType = categories.find(c => c.type === type);
    return anyOfType ? anyOfType.id : null;
  }

  function parseAmountBR(raw) {
    let s = String(raw).trim().replace(/[R$\s]/g, '');
    const negative = s.includes('-') || (s.startsWith('(') && s.endsWith(')'));
    s = s.replace(/[()\-]/g, '');
    if (s.includes(',') && s.includes('.')) {
      s = s.replace(/\./g, '').replace(',', '.');
    } else if (s.includes(',')) {
      s = s.replace(',', '.');
    }
    const val = parseFloat(s);
    if (isNaN(val)) return NaN;
    return negative ? -Math.abs(val) : val;
  }

  function normalizeDate(str) {
    str = String(str).trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(str)) return str.slice(0, 10);
    if (/^\d{8}/.test(str)) return `${str.slice(0, 4)}-${str.slice(4, 6)}-${str.slice(6, 8)}`;
    const m = str.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
    if (m) {
      let [, d, mo, y] = m;
      if (y.length === 2) y = '20' + y;
      return `${y}-${mo.padStart(2, '0')}-${d.padStart(2, '0')}`;
    }
    return null;
  }

  function parseOFX(text) {
    const blocks = text.split(/<STMTTRN>/i).slice(1);
    const txs = [];
    for (const block of blocks) {
      const body = block.split(/<\/STMTTRN>/i)[0];
      const get = (tag) => {
        const m = body.match(new RegExp(`<${tag}>([^<\\r\\n]*)`, 'i'));
        return m ? m[1].trim() : '';
      };
      const dateRaw = get('DTPOSTED');
      const amountRaw = get('TRNAMT');
      const memo = get('MEMO') || get('NAME') || 'Transação importada';
      if (!dateRaw || !amountRaw) continue;
      const date = normalizeDate(dateRaw);
      const amount = parseFloat(amountRaw);
      if (!date || isNaN(amount)) continue;
      txs.push({
        date,
        description: memo,
        type: amount < 0 ? 'despesa' : 'receita',
        amount: Math.abs(amount),
      });
    }
    return txs;
  }

  function detectDelimiter(line) {
    const commas = (line.match(/,/g) || []).length;
    const semis = (line.match(/;/g) || []).length;
    return semis > commas ? ';' : ',';
  }

  function parseCSV(text) {
    const lines = text.split(/\r?\n/).filter(l => l.trim().length > 0);
    if (lines.length < 2) return [];
    const delim = detectDelimiter(lines[0]);
    const header = lines[0].split(delim).map(h => h.trim().toLowerCase().replace(/["']/g, ''));

    const findCol = (keywords) => header.findIndex(h => keywords.some(k => h.includes(k)));
    const dateIdx = findCol(['data', 'date']);
    const descIdx = findCol(['descri', 'histor', 'title', 'lançamento', 'lancamento', 'memo', 'estabelecimento', 'nome']);
    const amountIdx = findCol(['valor', 'amount', 'value']);

    if (dateIdx === -1 || amountIdx === -1) return [];

    const txs = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(delim).map(c => c.trim().replace(/^"|"$/g, ''));
      if (cols.length <= Math.max(dateIdx, amountIdx)) continue;
      const dateRaw = cols[dateIdx];
      const amountRaw = cols[amountIdx];
      const description = descIdx !== -1 ? cols[descIdx] : 'Transação importada';
      if (!dateRaw || !amountRaw) continue;
      const date = normalizeDate(dateRaw);
      const amount = parseAmountBR(amountRaw);
      if (!date || isNaN(amount)) continue;
      txs.push({
        date,
        description: description || 'Transação importada',
        type: amount < 0 ? 'despesa' : 'receita',
        amount: Math.abs(amount),
      });
    }
    return txs;
  }

  function parseFile(filename, text) {
    const ext = filename.toLowerCase().split('.').pop();
    if (ext === 'ofx' || ext === 'qfx' || text.includes('<OFX>') || text.includes('<STMTTRN>')) {
      return parseOFX(text);
    }
    return parseCSV(text);
  }

  return { parseFile, guessCategoryId };
})();
